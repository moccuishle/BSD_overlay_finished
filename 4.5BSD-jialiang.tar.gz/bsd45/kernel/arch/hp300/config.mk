# config.mk - kernel/arch/hp300
#
# Per-directory build configuration for the BSD45 kernel.
# build_kernel.ps1 is the current driver; a kbuild-style build can
# pick up obj-y/obj-m/dir-y from here.

# obj-y += 
# obj-m += 
# dir-y += 

# subdirectories:
#   conf/
#   dev/
#   DOC/
#   hp300/
#   include/
#   scripts/
#   stand/
